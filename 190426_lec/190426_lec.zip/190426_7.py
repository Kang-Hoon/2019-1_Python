# Script Mode
#

name = input("What's your name? ")
gender = input("What is your gender? (M/F) ")
grade = input("What grade are you in? ")
int (grade)

if gender == 'F':
    print("DISCOUNT")
if grade == 1:
    print("DISCOUNT")
